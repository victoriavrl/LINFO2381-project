#!/usr/bin/env python3

import datetime
import random


##
## Initialization of the CouchDB server (creation of 1 collection of
## documents named "ehr", if it is not already existing)
##

import CouchDBClient

client = CouchDBClient.CouchDBClient()

# client.reset()   # If you want to clear the entire content of CouchDB

if not 'ehr' in client.listDatabases():
    client.createDatabase('ehr')


##
## Goal: Create a patient, record a few temperatures, retrieve the
## temperatures associated with the patient, and finally retrieve the
## name of all the patients stored in the CouchDB databases.
##

## 1. Create one new patient (which corresponds to an EHR in the
## framework of openEHR CDR) and associate it with a demographic
## information (i.e., patient's name)

patientName = 'John Doe n°%d' % random.randint(0, 1000)

# TODO



## 2. Record a few random temperatures

for i in range(10):
    temperature = random.uniform(35, 40)
    now = datetime.datetime.now().isoformat()

    # TODO
    


## 3. Retrieve all the temperatures that have just been stored, sorted
## by increasing time

# TODO



## 4. Retrieve the name of all the patients stored in the database

# TODO

